/*****************************
 *  AUTHOR Jonathan Wright
 *  PURPOSE To Show Errors
 *  DATEL 11/05/2019
 *
 */

class Error
{
/*
 *  Purpose: To show errors.
 *  Date: 11/05/2019
 *  Import: String error
 *  Export: Nothing
 */
    public static void showError(String error)
    {
        System.out.println(error);
    } // basically unrefactorable, its a single line


}
