Jonathan Wright Assignment Readme

Date created: 23/05/2019

Date last modified: 23/05/2019

Purpose: To create ships, calculate values related to ships, and store ships.

Files in project: Engine.java, Error.java, FighterJet.java, Filemanager.java, Readme.java, Ship.java, ShipManager.java, ShipManagerPsuedo, FighterJetPsuedo, ErrorPsuedo, EnginePsuedo, FileManagerPsuedo, ShipPsuedo, Submarine.java, SubmarinePsuedo, testFile.csv, UserInterface.java, UserInterfacePsuedo, WRIGHT_1977...pdf, Declarationof...pdf

Test Files: FighterJetTestHarness.java, ShipStorageTestHarness.java, SubmarineTestHarness.java, testFile.csv

Functionality: Will create ships, calculate values, and store ships, allow user input and output

TODO: none

Known bugs
    
    Additional functionality: none






Notes on Readme from the coding standard:
A README file should accompany each of your programs. This is a text file that explains the overall design of your project. When presenting your design you should discuss why you made the design choices you did. Anyone should be able to explain and defend your design by simply reading your README (without looking at your code). You should also discuss all known bugs, speculate about their cause, and suggest how they could be fixed. Finally you should include a description of any functionality that goes beyond the required specifications (i.e all the bells and whistles you added).



Previous tutor's extra tips:
Ask for help
	falling behind will be the death of you, tutors want to help but dont know when you need it
	if you find yourself falling behind for reasons beyond your control, let your tutor know so they can help you 
	be warned, if it is from laziness the tutor will be less likely to invest their own time in helping you because tutors are students with their own assignments and tests

some documents to help you will be uploaded weekly to help you study
	do not use them as a substitute for going to class
	do not copy code from them and submit in pracs or assignments
		i wrote the code, i can recognise when i see my own code

Google All the Things!
	There is no point trying hard to remember what you read or guess a library when you can google it
	google (and stack overflow) will answer many questions BUT BE WARNED
		stack overflow code is often written terribly and not to our coding standard, additionally they use methods we dont teach so if you copy straight from stack overflow we will be able to tell immediately
		use these resources to help you, not to copy from



Create a document for compile errors (1 document per language IE java, c etc)
	everytime you get a compile error copy the error message into this document 
	when you figure out/google tells you/tutor tells you what the error means write down what causes the error and how to fix it in this document
	when you get an error in the future, look it up and it will help you solve it


if firefox wont start because its "already running" 
    Go to your home directory ("cd") then change to the .mozilla/firefox directory. There will be one child directory (everyone has a different name) go to this directory.
    rm lock
    rm .parentlock
    start firefox.

swap file
	if you are informed that there is a "swap" or "swp" file when you try to open a file, this means that the file you are attempting to open is open somewhere else, 
	i recommend opening the file for viewing or copying a backup, then open edit anyway (or you may have to delete the swap file)


Explore the "Information Sheets" folder on blackboard under OOPD/Unit Materials
	it contains information about
		java coding standard
		pseudo code style guide
		how to Unix
		how to use Vi
		how to remote access lab machines
		how to transfer files to and from your home directory
		basic testing notes
		hints


